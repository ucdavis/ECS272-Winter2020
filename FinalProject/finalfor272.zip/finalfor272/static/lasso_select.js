var svg = d3.select("svg"),
    width = +svg.attr("width"),
    height = +svg.attr("height");

var color = d3.scaleOrdinal(d3.schemeCategory20);

var simulation = d3.forceSimulation()
    .force("link", d3.forceLink().id(function(d) { return d.id; }))
    .force("charge", d3.forceManyBody())
    .force("center", d3.forceCenter(width / 3, height / 3));



var totalsets = [];

var colors = ["red",'blue','pink','green'];

d3.selection.prototype.moveToBack = function() {
  return this.each(function() {
    var firstChild = this.parentNode.firstChild;
    if (firstChild) {
      this.parentNode.insertBefore(this, firstChild);
    }
  });
};



sortset = function(graph){
  let mapset = new Map();
  var data = graph;

  for (node of data){
    for (setnum of node.group){
      if (mapset.has(setnum)){
        mapset.get(setnum).push(node);
      }else{
        mapset.set(setnum,[node]);
      }
    }
  }
  a = [];
  for(var x of mapset)
    a.push(x);

  a.sort(function(x, y) {
    return -(x[1].length - y[1].length);
  });
  sorted = new Map();
  var label = 0;
  for (var x of a){
    console.log(x);
    sorted.set(label++,x[1]);

  }

  var finalmap = new Map();

  for (var x of sorted){
    for (var node of x[1]){
      console.log(node.id);
      var key = "";
      for (var i of sorted){
        if (i[1].includes(node)){
          key += i[0].toString();
        }
      }
      if (finalmap.has(key)) {
        finalmap.get(key).add(node.id);
      }
      else{
        var tset = new Set(node.id);
        finalmap.set(key,tset);
      }

    }
  }
  b = [];
  for(var x of finalmap)
    b.push(x);

  b.sort(function(x, y) {
    return(x<y?-1:(x>y?1:0));
  });
  finalmap = new Map(b);
  return finalmap;
};
d3.json("graph.json", function(error, graph) {
    if (error) throw error;
    sortset(graph);




    var link = svg.append("g")
        .attr("class", "links")
        .selectAll("line")
        .data(graph.links)
        .enter().append("line")
        .style("stroke-width", function(d) { return Math.sqrt(d.value); });


    var node = svg.append("g")
        .attr("class", "nodes")

        .selectAll("circle")
        .data(graph.nodes)
        .enter().append("rect")
        .attr("width",40)
        .attr("height", 20)
        .attr("rx", 10)
        .attr("ry", 10)
        .attr("fill",'#f0f0cc')
        .call(
          d3.drag()
            .on("start", dragstarted)
            .on("drag", dragged)
            .on("end", dragended));

    node.append("title")
        .text(function(d) { return d.id; });

    simulation
        .nodes(graph.nodes)
        .on("tick", ticked);

    simulation.force("link")
        .links(graph.links);

//*******

  var getSetrect = function (nodes1) {
    let sumx = 0;
    let sumy = 0;
    let minx = Number.MAX_SAFE_INTEGER;
    let miny = Number.MAX_SAFE_INTEGER;
    let maxx = 0;
    let maxy = 0;

    for (i in nodes1){
      sumx +=nodes1[i].x.baseVal["value"] + 15;
      sumy +=nodes1[i].y.baseVal["value"] + 10;
      minx = Math.min(minx,nodes1[i].x.baseVal["value"] + 15);
      miny = Math.min(miny,nodes1[i].y.baseVal["value"] + 10);
      maxx = Math.max(maxx, nodes1[i].x.baseVal["value"] + 15);
      maxy = Math.max(maxy, nodes1[i].y.baseVal["value"] + 10);
    }
    var swidth = maxx + 30 - (minx ) + 20;
    var sheight = maxy +20 - (miny ) + 20;
    console.log(nodes1.length,"node len");
    sumx /= nodes1.length;
    sumy /= nodes1.length;
    return [sumx,sumy,swidth,sheight];

  };

// Lasso functions
    var lasso_start = function() {

      console.log("in lasso start");
      console.log(totalsets);
        lasso.items()
            .attr("rx", 10)
          .attr("ry",10)
            .classed("not_possible",true)
            .classed("selected",false);
    };

    var lasso_draw = function() {

        // Style the possible dots
        lasso.possibleItems()
            .classed("not_possible",false)
            .classed("possible",true);

        // Style the not possible dot
        lasso.notPossibleItems()
            .classed("not_possible",true)
            .classed("possible",false);
    };


    var lasso_end = function() {
        lasso.items()
            .classed("not_possible",false)
            .classed("possible",false);

        // Style the selected dots
      console.log(lasso.selectedItems()._groups[0]);
      nodes1 = lasso.selectedItems()._groups[0];
      nodesin = [];
      for (new_ of nodes1){
        for(set of totalsets){
          for (old of set) {
            if (old.__data__.id === new_.__data__.id) {
              nodesin.push(new_)
              console.log("in", old.__data__.id, new_.__data__.id);
            }
          }
        }
      }
      console.log(nodesin,"nodesin");
      for (i of nodesin){
        nodes1 = nodes1.filter(function(value,index,arr){return value !== i });

      }
      console.log(nodes1,"poped","nodesin",nodesin);

      let node1attr = getSetrect(nodes1);
      let nodesinattr = getSetrect(nodesin);
      var sumx = node1attr[0], sumy = node1attr[1], swidth = node1attr[2], sheight = node1attr[3];
      var nsumx = nodesinattr[0],nsumy = nodesinattr[1],nswidth = nodesinattr[2], nsheight = nodesinattr[3];
      console.log("lassso end",sumx,sumy);
      let newset = lasso.selectedItems()._groups[0];
      if (newset.length !== 0) {
        totalsets.push(newset);
      }
      console.log(totalsets);
        lasso.selectedItems()
            .classed("selected",true)
            .attr("rx",10)
            .attr("ry", 10)

        // Reset the style of the not selected dots
      console.log(totalsets.length,'len');
      if (newset.length !== 0) {
        var set = svg.selectAll("set")
          .data(nodes1)
          .enter().append("rect")
          .attr("width", swidth)
          .attr("height", sheight)
          .attr('rx', 10)
          .attr('ry', 10)
          .attr("x", sumx - (swidth / 2))
          .attr("y", sumy - (sheight / 2))
          .style("stroke", 'black')
          .style("stroke-width", 5)
          .style('opacity',0.2)
          .attr('fill', colors[totalsets.length % 4]);
        set.lower();

      }
      if (nodesin.length !== 0) {
        var news = svg.selectAll("set")
          .data(nodesin)
          .enter().append("rect")
          .attr("width", swidth)
          .attr("height", sheight)
          .attr('rx', 10)
          .attr('ry', 10)
          .attr("x", nsumx - (nswidth / 2))
          .attr("y", nsumy - (nsheight / 2))
          .style("stroke", 'black')
          .style("stroke-width", 5)
          .style('opacity',0.2)
          .attr('fill', colors[totalsets.length % 4]);
        news.lower();


      }
    node.raise();

    };

    var lasso = d3.lasso()
        .closePathSelect(true)
        .closePathDistance(100)
        .items(node)
        .targetArea(svg)
        .on("start",lasso_start)
        .on("draw",lasso_draw)
        .on("end",lasso_end);

    svg.call(lasso);


    function ticked() {
      console.log("ticked");
        link
            .attr("x1", function(d) { return d.source.x; })
            .attr("y1", function(d) { return d.source.y; })
            .attr("x2", function(d) { return d.target.x; })
            .attr("y2", function(d) { return d.target.y; });

        node
            .attr("x", function(d) { return d.x; })
            .attr("y", function(d) { return d.y; })
            .attr("rx", function(d) { return d.rx;})
            .attr("ry", function(d) { return d.ry;});
    }
});


function dragstarted(d) {

    if (!d3.event.active) simulation.alphaTarget(0).restart();
    console.log(d, "dragstarted");
    d.fx = d.x;
    d.fy = d.y;



}

function dragged(d) {
  console.log(d3.event,"dragged");
  d.fx = d3.event.x;
    d.fy = d3.event.y;

}

function dragended(d) {
  console.log(d,"dragend");

  if (!d3.event.active) simulation.alphaTarget(0);
    d.fx = d.x;
    d.fy = d.y;
}
