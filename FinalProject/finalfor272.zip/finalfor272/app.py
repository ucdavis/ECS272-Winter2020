from flask import Flask,render_template,url_for,request
import json
from collections import defaultdict
app = Flask(__name__)




shakespeare = open("graph.txt",'r')

sgraph = json.load(shakespeare)

print(sgraph)
with open("graph.json",'r') as f:

    graph = json.load(f)

graph = json.dumps(graph)
print(graph)


# graph = { "0":[1,2,3],
#           "1":[4,5,6]
# }
def sortgraph(graph):

    graph = sorted(graph.items(),key=lambda x:-len(x[1]))

    sortedorder = {}
    for i in range(len(graph)):
        sortedorder[str(i)] = graph[i][1]
    #print(sortedorder)
    result = defaultdict(list)
    for key in sortedorder:
        for val in sortedorder[key]:
            result[val].append(key)
    new = defaultdict(list)
    for key in result:
        new["".join(sorted(result[key]))].append(key)
    sortedres = dict(sorted(new.items(),key=lambda x:x[0]))

    return sortedres

print(sortgraph(sgraph))

#
# newgraph1 = defaultdict(list)
# for i in sgraph:
#     for j in sgraph[i]:
#         newgraph1[j].append(i)
#
# print(newgraph1)
newgraph = {}
newgraphc = {}
@app.route('/')
def Home():
    global fromlasso
    fromlasso = False
    return render_template("home.html")
fromlasso = False

@app.route('/done',methods=["POST"])

def done():
    global newgraph,fromlasso
    fromlasso = True
    if request.method == "POST":
        temp = request.get_json()

        for i,node in enumerate(temp['totalsetlabel']):
            newgraph[str(i)] = node
        print(newgraph)
        return json.dumps({"success":True}),200,{"ContentType":"application/json"}

@app.route('/donec',methods=["POST"])

def donec():
    global newgraphc,fromlasso
    fromlasso = True
    if request.method == "POST":
        temp = request.get_json()
        print(temp,"temp")
        newgraphc = temp
        newgraphc = dict(sorted(newgraphc.items(), key=lambda x: x[0]))
        print(newgraphc)
        return json.dumps({"success":True}),200,{"ContentType":"application/json"}
@app.route('/Dup',methods=["GET"])

def Duped():
    newgraph1 = defaultdict(list)

    for i in newgraph:
        for j in newgraph[i]:
            newgraph1[j].append(i)

    return render_template("DupED.html",graph1 = json.dumps(newgraph),graph = json.dumps(newgraph1),froml = fromlasso)
@app.route('/Com')
def Comed():

    return render_template("ComED.html",graph = json.dumps(newgraphc),froml = fromlasso)

@app.route('/Lasso')
def Lasso():
    return render_template("Lasso.html",graph = graph)

@app.route("/ShakesCom")

def ShakespeareCom():

    newgraph = sortgraph(sgraph)
    return render_template("ShakespeareCom.html",graph = json.dumps(newgraph))

@app.route("/ShakesDup")

def ShakespeareDup():
    print(sgraph,"s")
    newgraph1 = defaultdict(list)
    for i in sgraph:
        for j in sgraph[i]:
            newgraph1[j].append(i)
    print(newgraph1)

    return render_template("ShakespeareDup.html",graph1 = json.dumps(sgraph),graph = json.dumps(newgraph1))
def hello_world():
    return 'Hello World!'


if __name__ == '__main__':
    app.run()
